
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Konseyİnşaat</title>
    <link rel="stylesheet" href="hakk.css">
	<link>
	<style>
body {
    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');
    *

{
    MARGİN: 0;
    PADDİNG: 0;
}

.container {
    background: url(arka.jpg);
    height: 97.8vh;
    background-size: 100% 100%;
    border-radius: 25px;
}

    .container .navbar {
        width: 100%;
        height: 80px;
        background: black;
        cursor: pointer;
        outline: none;
        border-radius: 25px;
    }

.navbar .logo {
    display: inline-block;
    margin-left: 50px;
    margin-top: 20px;
}

    .navbar .logo a {
        text-decoration: none;
        font-size: 30px;
        font-family: sans-serif;
        color: white;
        font-family: Stencil;
    }

.navbar ul {
    float: right;
    margin-right: 20px;
}

    .navbar ul li {
        list-style: none;
        display: inline-block;
        margin: 0 8px;
        line-height: 80px;
        line-height: 40px;
    }

        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 15px;
            padding: 6px 13px;
            font-family: Roboto;
        }

            .navbar ul li a.active,
            .navbar ul li a:hover {
                background: #ff6e00;
                border-radius: 2px;
                border-radius: 25px;
            }

.container .center {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    font-family: sans-serif;
    user-select: none;
}

.center h1 {
    color: black;
    font-size: 70px;
    font-weight: bold;
    width: 900px;
    text-align: center;
}


</style>
</link>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="http://localhost/ana.php">KONSEY INSAAT</a>

            </div>
            <ul>
                <li><a href="http://localhost/ana.php" class="active">ANA SAYFA</a></li>
                <li><a href="http://localhost/ürünler.php">URUNLER</a></li>
                <li><a href="#">HAKKIMIZDA</a></li>
				<li><a href="http://localhost/siparisver.php">SIPARIS VER</a></li>
                
            </ul>
        </div>
        <br><br><br>
            <h1><center>HAKKIMIZDA</center></h1>
            <div class="açıklama"><center>Hoş geldiniz! Konsey İnşaat, inşaat sektöründe uzmanlaşmış, müşteri odaklı ve kaliteli hizmet anlayışıyla öne çıkan bir şirkettir. Yılların birikimi ve sektördeki deneyimimizle, müşterilerimize sürdürülebilir, güvenilir ve estetik çözümler sunmayı hedefliyoruz.</center></div>
			<h2><center>VİZYONUMUZ</center></h2> <div class="açıklama"><center>Konsey İnşaat olarak vizyonumuz, müşteri memnuniyetini esas alarak, inşaat sektöründe kalite standartlarını yükseltmek ve projelerimizle topluma değer katmaktır. Yaratıcı çözümler üreterek, sürdürülebilir yapılar inşa etmek, çevresel faktörlere duyarlı projeler geliştirmek ve sektörde lider bir konuma ulaşmak en önemli hedeflerimiz arasındadır.</center></div>
<h2><center>MİSYONUMUZ</center></h2><div class="açıklama"><center>Müşterilerimize en iyi hizmeti sunmak ve projelerimizde kaliteyi ön planda tutarak güvenilir inşaat çözümleri sunmak, misyonumuzun temelini oluşturur. Yenilikçi yaklaşımlarımız, güçlü uzman kadromuz ve sektördeki gelişmeleri yakından takip ederek, projelerimizi her aşamada mükemmeliyetle tamamlamak, işimizin temel taşlarındandır.</center></div>

        


    </div>
</body>
</html>