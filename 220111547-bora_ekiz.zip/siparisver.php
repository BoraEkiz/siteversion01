<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Konsey İnşaat/SiparişVer</title>
    <link rel="stylesheet" href="style.css">
	<link>
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');
*{
    MARGİN:0;
    PADDİNG:0;
}

.container{
    background:url(arka.jpg);
    height:97.8vh;
    background-size:100% 100%;
    border-radius: 25px;

}

    .container .navbar {
        width: 100%;
        height: 80px;
        background: black;
        cursor: pointer;
        outline: none;
        border-radius: 25px;
    }

.navbar .logo{
    display:inline-block;
    margin-left:50px;
    margin-top:20px;
}

.navbar .logo a{
    text-decoration:none;
    font-size:30px;
    font-family:Stencil;
    color:white

}

.navbar ul{
    float:right;
    margin-right:20px;
}

    .navbar ul li {
        list-style: none;
        display: inline-block;
        margin: 0 8px;
        line-height: 80px;
        line-height: 40px;
    }
    .navbar ul li a{
        color:white;
        text-decoration:none;
        font-weight:bold;
        font-size:15px;
        padding:6px 13px;
        font-family:Roboto;

    }

        .navbar ul li a.active,
        .navbar ul li a:hover {
            background: #ff6e00;
            border-radius: 2px;
            border-radius: 25px;
        }
		.iletisim {
			 text-align: center;
		}
		.iletisim .ilet .table{
			 text-align: center;
			 background: #ff6e00;
            border-radius: 2px;
            border-radius: 25px;
            margin-left: 44%;
  margin-right:44%;
		}
</style>
</link>	
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="http://localhost/ana.php">KONSEY INSAAT</a>
                
            </div>
            <ul>
                <li><a href="http://localhost/ana.php" class="active">ANA SAYFA</a></li>
                <li><a href="http://localhost/ürünler.php">URUNLER</a></li>
                <li><a href="http://localhost/hakkimizda.php">HAKKIMIZDA</a></li>
                <li><a href="http://localhost/siparisver.php">SIPARIS VER</a></li>

                
            </ul>
        </div>
<form method="post" action="">
        <div class="iletisim">
            <div class="ilet">
                <h3 class="text-center">SİPARİŞ VER</h3>
                <table class="table">
                    <tbody>
                        <tr>
                            <td>
                                <strong>AD:</strong><input type="text" name="ad" value="" size="30"><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Adres:</strong><input type="text" name="adres" value="" size="30"><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>TelNo:</strong><input type="text" name="tel" value="" size="30"><br><br>
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <strong>Ürün Adı:</strong><input type="text" name="ürün" value="" size="30"><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                <input type="submit" class="btn btn-primary btn-block" id="btnGonder" value="Sipariş Ver">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </form>
        </div>

      
        </div>

</body>
</html>
<?php
$baglan = new mysqli("localhost", "root", "", "malzeme");
if ($baglan->connect_error) {
    die("Hata:" . $baglan->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad = $_POST['ad'];
    $adres = $_POST['adres'];
    $tel = $_POST['tel'];
    $ürün = $_POST['ürün'];


    $stmt = $baglan->prepare("INSERT INTO siparis (ad, adres, tel,ürün) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $ad, $adres, $tel,$ürün);

    if ($stmt->execute()) {
        echo " veri başarıyla eklendi.";
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
    $baglan->close();
}

?>
