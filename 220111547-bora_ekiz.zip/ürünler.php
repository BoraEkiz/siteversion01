<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Konsey İnşaat/Ürünler</title>
    <link rel="stylesheet" href="style.css">
	<link>
	<style>
	body{
    margin: 0px;
    padding: 0px;
}
body {


    MARGİN: 0;
    PADDİNG: 0;
}

.container {
    background: url(arka.png);
    height: 97.8vh;
    background-size: 100% 100%;
    border-radius: 25px;
}

    .container .navbar {
        width: 100%;
        height: 80px;
        background: black;
        cursor: pointer;
        outline: none;
        border-radius: 25px;
    }

.navbar .logo {
    display: inline-block;
    margin-left: 50px;
    margin-top: 20px;
}

    .navbar .logo a {
        text-decoration: none;
        font-size: 30px;
        font-family: sans-serif;
        color: white;
        font-family: Stencil;
    }

.navbar ul {
    float: right;
    margin-right: 20px;
}

    .navbar ul li {
        list-style: none;
        display: inline-block;
        margin: 0 8px;
        line-height: 80px;
        line-height: 40px;
    }

        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 15px;
            padding: 6px 13px;
            font-family: Roboto;
        }

            .navbar ul li a.active,
            .navbar ul li a:hover {
                background: #ff6e00;
                border-radius: 2px;
                border-radius: 25px;
            }

.orta-tam{
    width: 100%;
    padding-top:100px;
}
.orta-tam img{
    width: 100%;
    height: 200px;
}

.yazı-orta{
    position: relative;

    text-align: center;
    color: black;
}
.yazı-orta h1{
    font-size: 45px;
    text-shadow: 0px 0px 40px blue;
}
.yazı-orta span{
    font-size: 25px;
}
.açıklama{
    width: 100%;
    margin-top:-100px;
    padding-left:100px;
    padding-right:100px;
    box-sizing:border-box;
    font-size: 15pt;
    text-align: center; 
}
.orta{
    width: 100%;
}
.card{
 width: 25%;
 padding: 10px;
 box-sizing: border-box;
 float: left;
 margin-left:6.25%;
 border: 1px solid transparent;
 transition: 0.3s linear;
}
.card img{
    width: 100%;
    height: 200px;
    filter: grayscale(50%) sepia(50%);
    transition: 0.3s linear;
}
.card h3{
    text-align: center;
}
.card span{
    color: gray;
    text-indent: 25px;
    text-align: center;
    display: block;
}
.card:hover{
    border: 1px solid gray;
}
.card:hover img{
    filter: none;
}
</style>
</link>
</head>

<body>
 <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="http://localhost/ana.php">KONSEY INSAAT</a>
                
            </div>
		<ul>
			<li><a href="http://localhost/ana.php" class="active">ANA SAYFA</a></li>
			<li><a href="http://localhost/ürünler.php">URUNLER</a></li>
			<li><a href="http://localhost/hakkimizda.php">HAKKIMIZDA</a></li>
			<li><a href="http://localhost/siparisver.php">SIPARIS</a></li>
			<li><a href="http://localhost/ürünekle.php" >ÜRÜN EKLE</a></li>
		</ul>
	<div class="orta-tam">
		
		<div class="yazı-orta">
			<br>
			<span></span>
		</div>
	</div>
	<br><br>
	<div class="çerçeve">
		<div class="orta">
		</div>
		</div>
		<?php
// Veritabanı bağlantısı
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malzeme";

$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Ürünler tablosundan verileri çekme
$sql = "SELECT id, ÜrünAdi, Resim FROM Ürünler";
$result = $conn->query($sql);

// HTML başlığı


// Verileri ekrana bastırma
$ilansayac = 0;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($ilansayac % 3 === 0) {
            if ($ilansayac > 0) {
                echo "</div><br>"; // Add a line break and close the previous div after every fourth product (except the first row)
            }

            echo "<div style='margin-bottom: 20px; display: inline-block;'>";
        }

        echo $row["id"];
		
        echo $row["ÜrünAdi"];
        echo '<img src="Resimler/' . $row["Resim"] . '" alt="' . $row["ÜrünAdi"] . '" style="width:390px;height:390px;">';
        $ilansayac++;
    }
    echo "</div>"; // Close the last div
} else {
    echo "0 sonuç";
}

// Bağlantıyı kapat
$conn->close();

// HTML sayfa kapatma
echo "</body></html>";
?>

				
				
			
</body>
</html>