﻿<html>
<head>
</head>
<body>
    <style>
	<link>
	@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');
*{
    MARGİN:0;
    PADDİNG:0;
}

.container{
    background:url(arka.jpg);
    height:97.8vh;
    background-size:100% 100%;
    border-radius: 25px;

}

    .container .navbar {
        width: 100%;
        height: 80px;
        background: black;
        cursor: pointer;
        outline: none;
        border-radius: 25px;
    }

.navbar .logo{
    display:inline-block;
    margin-left:50px;
    margin-top:20px;
}

.navbar .logo a{
    text-decoration:none;
    font-size:30px;
    font-family:Stencil;
    color:white

}

.navbar ul{
    float:right;
    margin-right:20px;
}

    .navbar ul li {
        list-style: none;
        display: inline-block;
        margin: 0 8px;
        line-height: 80px;
        line-height: 40px;
    }
    .navbar ul li a{
        color:white;
        text-decoration:none;
        font-weight:bold;
        font-size:15px;
        padding:6px 13px;
        font-family:Roboto;

    }

        .navbar ul li a.active,
        .navbar ul li a:hover {
            background: #ff6e00;
            border-radius: 2px;
            border-radius: 25px;
        }
		
       

        form {
            text-align: center;
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        strong {
            display: block;
            margin-top: 10px;
        }

        select, input[type="text"], input[type="file"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
            padding: 10px;
            border: none;
            border-radius: 3px;
        }

            input[type="submit"]:hover {
                background-color: #45a049;
            }
    </style>
	</link>
	<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="http://localhost/ana.php">KONSEY INSAAT</a>
                
            </div>
            <ul>
                <li><a href="http://localhost/ana.php" class="active">ANA SAYFA</a></li>
                <li><a href="http://localhost/ürünler.php">URUNLER</a></li>
                <li><a href="http://localhost/hakkimizda.php">HAKKIMIZDA</a></li>
                <li><a href="http://localhost/siparisver.php">SIPARIS VER</a></li>

                
            </ul>
        </div>
    <form action="ürünekle.php" method="post" enctype="multipart/form-data" style="text-align:center;">

        <strong>Ürünadi:</strong><input type="text" name="Ürünadi" value="" size="30">
        <br><br>
        
        <strong>Resim:</strong> <input type="file" name="resim"><br><br>
        <input type="submit" value="Kaydet">
    </form>

</body>
</html>

<?php
$baglan = new mysqli("localhost", "root", "", "malzeme");
if ($baglan->connect_error) {
    die("Hata:" . $baglan->connect_error);
}
$baglan->set_charset("utf8");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Ürünadi = $_POST["Ürünadi"];
   
    if (isset($_FILES["resim"]) && $_FILES["resim"]["error"] == 0) {
        $allowed_extensions = array("jpg", "jpeg", "png");
        $file_extension = pathinfo($_FILES["resim"]["name"], PATHINFO_EXTENSION);

        if (!in_array(strtolower($file_extension), $allowed_extensions)) {
            die("Sadece JPG, JPEG veya PNG formatındaki resim dosyalarını yükleyebilirsiniz.");
        }
        $resim = $_FILES["resim"]["name"];
        $resim_temp = $_FILES["resim"]["tmp_name"];
        $resim_yolu = "resimler/" . $resim;
    } else {
        die("Lütfen geçerli bir resim dosyası seçin.");
    }
    if (empty($Ürünadi)) {
        die("Lütfen tüm alanları doldurun.");
    }
    $sorgu = $baglan->prepare("INSERT INTO Ürünler (Ürünadi, resim) VALUES (?, ?)");
    if (!$sorgu) {
        die("Sorgu hatası: " . $baglan->error);
    }
    $sorgu->bind_param("ss", $Ürünadi,$resim);
    if ($sorgu->execute()) {
        $toplam = $sorgu->affected_rows;
        $sorgu->close();
        $baglan->close();

        if ($toplam > 0) {
            echo "Ürün Yüklendi.";
            header("refresh:5;url=ana.php");
            exit;
        } else {
            echo "Ürün Yüklenemedi.";
        }
    } else {
        die("Sorgu çalıştırma hatası: " . $sorgu->error);}}
?>