<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Konsey İnşaat/Ana Sayfa</title>
    <link rel="stylesheet" href="style.css">
	<link>
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');
*{
    MARGİN:0;
    PADDİNG:0;
}

.container{
    background:url(arka.jpg);
    height:97.8vh;
    background-size:100% 100%;
    border-radius: 25px;

}

    .container .navbar {
        width: 100%;
        height: 80px;
        background: black;
        cursor: pointer;
        outline: none;
        border-radius: 25px;
    }

.navbar .logo{
    display:inline-block;
    margin-left:50px;
    margin-top:20px;
}

.navbar .logo a{
    text-decoration:none;
    font-size:30px;
    font-family:Stencil;
    color:white

}

.navbar ul{
    float:right;
    margin-right:20px;
}

    .navbar ul li {
        list-style: none;
        display: inline-block;
        margin: 0 8px;
        line-height: 80px;
        line-height: 40px;
    }
    .navbar ul li a{
        color:white;
        text-decoration:none;
        font-weight:bold;
        font-size:15px;
        padding:6px 13px;
        font-family:Roboto;

    }

        .navbar ul li a.active,
        .navbar ul li a:hover {
            background: #ff6e00;
            border-radius: 2px;
            border-radius: 25px;
        }

    .container .center{
        position:absolute;
        top:50%;
        left:50%;
        transform:translate(-50%,-50%);
        font-family:sans-serif;
        user-select:none;
    }

    .center h1{
        color:black;
        font-size:70px;
        font-weight:bold;
        width:900px;
        text-align:center;
    }
.center h2 {
    color: #ffff;
    font-size: 50px;
    font-weight:bold;
    width: 885px;
    margin-top: 10px;
    text-align: center;
}

.center .buttons {
    margin:35px 280px;
}

.buttons button{
    height:50px;
    width:150px;
    font-size:18px;
    font-weight:bold;
    color:black;
    background-color:coral;
    border:solid 1px black;
    cursor:pointer;
    outline:none;
    border-radius:25px;
}

.buttons button:hover{
    background: #ffffff;
}
</style>
</link>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="http://localhost/ana.php">KONSEY INSAAT</a>
                
            </div>
            <ul>
                <li><a href="http://localhost/ana.php" class="active">ANA SAYFA</a></li>
                <li><a href="http://localhost/ürünler.php">URUNLER</a></li>
                <li><a href="http://localhost/hakkimizda.php">HAKKIMIZDA</a></li>
                <li><a href="http://localhost/siparisver.php">SIPARIS</a></li>

                
            </ul>
        </div>
        <div class="center">
            <h1>Konsey Insaat Firmamıza Hoş Geldiniz</h1>
           
            <div class="buttons">
                <button><a href="http://localhost/ürünler.php">ÜRÜNLER</a></button>
                <button><a href="http://localhost/siparisver.php">SİPARİS VER</a></button>
                
            </div>
            </div>   
        </div>

</body>
</html>